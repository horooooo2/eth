export const goldStrategy = {
  id: 'gold-range' as const, name: '区间回归策略', subtitle: '双向高抛低吸 · 分层补仓', version: 'legacy-244f7a9', minimum: 1200,
  description: '原版双向震荡、阶梯补仓及深跌补多规则。',
};
export function createReplayWorker(): Worker {
  return new Worker(new URL('./replay.worker.ts', import.meta.url), { type: 'module' });
}

export function isGoldStrategyReport(report: { strategyId?: string; strategyName: string }): boolean {
  return report.strategyId ? report.strategyId === goldStrategy.id : ['黄金震荡＋补仓', goldStrategy.name].includes(report.strategyName);
}
