// Historical parity test: real Worker logic, without a browser or live orders.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { execFileSync } = require('node:child_process');
const ts = require('typescript');
const root = path.resolve(__dirname, '../..');
const ref = '244f7a9e6177141b8474a1e81f5b8c0847d70402';
const workerPath = 'whale-tracker-frontend/src/tradfi-replay/replay.worker.ts';
const normalize = s => s.replace(/\r\n/g, '\n');
const historical = p => execFileSync('git', ['show', `${ref}:${p}`], { cwd: root, encoding: 'utf8' });
const source = fs.readFileSync(path.join(root, workerPath), 'utf8');
const corePath = 'whale-tracker-backend/lib/tradfiRangeCore.cjs';
const withoutMetrics = code => normalize(code).replace(/\s*\/\/ BEGIN SHARED METRICS[\s\S]*?\/\/ END SHARED METRICS/g, '').replace(/while \(index < end\) \{\s*processBar\(candles\[index\+\+\]\);\s*\}/g, 'while (index < end) processBar(candles[index++]);');
assert.equal(withoutMetrics(source), normalize(historical(workerPath)), 'Only shared equity reporting may differ from historical strategy');
assert.equal(normalize(fs.readFileSync(path.join(root, corePath), 'utf8')), normalize(historical(corePath)));
const core = require(path.join(root, corePath));
const settings = {symbol:'XAUUSDT',marginUsdt:10,leverage:10,makerFee:0.0002,tickSize:0.01,qtyStep:0.001,walletBalance:40000,orderTtlMs:90000};
function candles(mode, count = 6000) {
  const start = Date.parse('2025-01-06T00:00:00Z');
  return Array.from({length:count},(_,i)=>{
    const base = j => 3000 + 12*Math.sin(j/25) + 5*Math.sin(j/240) + (mode==='up'?j*.06:mode==='down'?-j*.06:0);
    const o=base(i),c=base(i+1);return {t:start+i*60000,o,h:Math.max(o,c)+1,l:Math.min(o,c)-1,c,v:100};
  });
}
async function run(code, rows, stopAt = rows.length) {
  const messages=[];
  const scope={postMessage: m=>messages.push(structuredClone(m)),setInterval,clearInterval};
  const context=vm.createContext({self:scope,core,setTimeout,clearTimeout,setInterval,clearInterval,console});
  const js=ts.transpileModule(code.replace("import core from '@core/tradfiRangeCore.cjs';",''),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
  vm.runInContext(js+'\nself.testAdvance=advance;',context);
  const funding=rows.filter((_,i)=>i%480===0).map(x=>({t:x.t,rate:0.0001}));
  scope.onmessage({data:{type:'init-start',candleCount:rows.length,settings,funding}});
  for(let offset=0;offset<rows.length;offset+=4000){
    const part=rows.slice(offset,offset+4000);
    const flat=new Float64Array(part.flatMap(x=>[x.t,x.o,x.h,x.l,x.c,x.v]));
    scope.onmessage({data:{type:'init-chunk',start:offset,count:part.length,buffer:flat.buffer}});
  }
  scope.onmessage({data:{type:'init-complete'}});
  for(let i=0;i<200&&!messages.some(m=>m.type==='ready');i++)await new Promise(r=>setTimeout(r,5));
  assert.ok(messages.some(m=>m.type==='ready'),'Worker must initialize');
  assert.ok(!messages.some(m=>m.type==='replay-error'));
  scope.testAdvance(stopAt);
  const snapshot=messages.filter(m=>m.type==='tick').at(-1).payload;
  scope.onmessage({data:{type:'export'}});
  const logs=messages.at(-1).payload;
  assert.equal(logs.length,snapshot.logsTotal);
  assert.ok(snapshot.tradeCount>=logs.length); // Trade count includes opening/addition fills.
  assert.ok(Math.abs(logs.reduce((s,r)=>s+r.pnl,0)-snapshot.realized)<1e-7);
  assert.ok(Math.abs(snapshot.realizedBySide.long+snapshot.realizedBySide.short-snapshot.realized)<1e-7);
  assert.ok(Math.abs(snapshot.net-snapshot.realized-snapshot.unrealized)<1e-7);
  assert.ok(logs.every(r=>Number.isFinite(r.pnl)&&r.openedAt<=r.closedAt));
  if ('equity' in snapshot) {
    assert.ok(Math.abs(snapshot.equity-settings.walletBalance-snapshot.net)<1e-7);
    assert.ok(snapshot.maxDrawdown>=0 && snapshot.maxDrawdownPct>=0);
    delete snapshot.equity;delete snapshot.maxDrawdown;delete snapshot.maxDrawdownPct;
  }
  delete snapshot.startedAt; // Wall-clock initialization time is not market data.
  return {snapshot,logs};
}
(async()=>{
  for(const mode of ['range','up','down']){
    const rows=candles(mode);
    const restored=await run(source,rows),original=await run(historical(workerPath),rows);
    assert.deepEqual(restored,original,`${mode} must have identical fills, positions and PnL`);
    assert.ok(restored.logs.length>0,`${mode} fixture must exercise real closes`);
    console.log(`${mode}: parity passed, ${restored.logs.length} closes, net=${restored.snapshot.net.toFixed(6)}`);
  }
  const rows=candles('range');
  const full=await run(source,rows,3500),prefix=await run(source,rows.slice(0,3500));
  for(const value of [full.snapshot,prefix.snapshot]){delete value.total;delete value.progress;delete value.paused;}
  assert.deepEqual(full,prefix,'Future candles must not alter the same prefix');
  console.log('Prefix causality and PnL reconciliation passed');
  if(process.argv.includes('--fixture')){
    fs.writeFileSync(path.join(root,'market-data/XAUUSDT_restore_test_SYNTHETIC.csv'),'timestamp,open,high,low,close,volume\n'+rows.map(x=>[x.t,x.o,x.h,x.l,x.c,x.v].join(',')).join('\n'));
  }
})().catch(err=>{console.error(err);process.exitCode=1;});
