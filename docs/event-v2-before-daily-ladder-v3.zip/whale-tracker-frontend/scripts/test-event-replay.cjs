const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),ts=require('typescript');
const source=fs.readFileSync(path.join(__dirname,'../src/tradfi-replay/exhaustionEngine.ts'),'utf8');
const context={exports:{}};vm.runInNewContext(ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText,context);
const {ExhaustionEngine,EVENT_RULES}=context.exports;
const MIN=60000,HOUR=60*MIN,T=Date.parse('2025-01-01T00:00:00Z');
const settings={symbol:'BTCUSDT',marginUsdt:10000,leverage:3,walletBalance:40000,takerFee:.0005,slippage:.0005,tickSize:.01,qtyStep:.001,riskUsdt:100,maxHoldHours:1};
function background(impulse=true){return Array.from({length:74*60},(_,i)=>{
 const h=Math.floor(i/60),m=i%60,o=100+h*.05+(h===73&&impulse?6:0)*m/60,c=h===73&&impulse?100+h*.05+6*(m+1)/60:o+.05/60;
 return {t:T+i*MIN,o,h:Math.max(o,c)+.15,l:Math.min(o,c)-.15,c,v:100};
});}
function extend(rows,count,end){const initial=rows.at(-1).c;for(let i=0;i<count;i++){const o=i?rows.at(-1).c:initial,c=initial+(end-initial)*(i+1)/count;rows.push({t:rows.at(-1).t+MIN,o,h:Math.max(o,c)+.01,l:Math.min(o,c)-.01,c,v:100});}return rows;}
function fixture(){const rows=background();extend(rows,5,108.8);extend(rows,5,109.1);extend(rows,5,108.6);return rows;}
const run=(rows,s=settings,funding=[])=>{const e=new ExhaustionEngine(s,funding);rows.forEach(b=>e.step(b));return e;};
const norm=x=>JSON.parse(JSON.stringify(x));
function reconcile(e,price){const sum=e.logs.reduce((s,l)=>s+l.pnl,0);assert.ok(Math.abs(sum-e.realized)<1e-8);assert.ok(Math.abs(e.realizedBySide.long+e.realizedBySide.short-sum)<1e-8);assert.ok(Math.abs(e.view(price).net-e.realized-e.pnl(price))<1e-8);assert.ok(Math.abs(e.equity-settings.walletBalance-e.view(price).net)<1e-7);}
assert.equal(run(background(false)).tradeCount,0,'A slow trend does not open a base position');
let rows=background();let e=run(rows);assert.equal(e.counts.detected,1);assert.equal(e.tradeCount,0,'An abnormal impulse alone is not entry');
const originalAtr=e.events[0].atr,originalId=e.events[0].id;
extend(rows,10,113);rows.slice(4440).forEach(b=>e.step(b));assert.equal(e.tradeCount,0);assert.equal(e.events[0].id,originalId);assert.equal(e.events[0].atr,originalAtr,'New extremes cannot reset ATR or the episode');
rows=fixture();e=run(rows);assert.equal(e.counts.confirmed,1);assert.equal(e.tradeCount,0,'Signal close is not an executable fill');
extend(rows,1,108.6);e.step(rows.at(-1));assert.equal(e.position.side,'short');assert.equal(e.position.openedAt,rows.at(-1).t);assert.ok(e.position.plannedRisk<=100);assert.equal(e.position.fills.length,1);
const entry=e.position.avg,stop=e.position.stop,target=e.position.target,qty=e.position.qty;
let b={t:rows.at(-1).t+MIN,o:108.6,h:stop+1,l:target-1,c:108.6,v:100};e.step(b);
assert.equal(e.logs[0].reason,'价格止损','Ambiguous minute uses adverse stop before target');assert.ok(e.logs[0].pnl<0);assert.equal(e.position,null);assert.equal(e.tradeCount,2);reconcile(e,b.c);
for(let i=0;i<30;i++){b={...b,t:b.t+MIN,h:108.61,l:108.59};e.step(b);}assert.equal(e.tradeCount,2,'No averaging down or same-direction rebuilding');
// Gaps through a stop are not optimistically filled at the old stop price.
rows=fixture();extend(rows,1,108.6);e=run(rows);b={t:rows.at(-1).t+MIN,o:120,h:121,l:119,c:120,v:1};e.step(b);assert.equal(e.logs[0].reason,'跳空止损');assert.ok(e.logs[0].pnl < -e.logs[0].plannedRisk);
// Re-check RR using the executable next open: do not chase an already completed reversal.
rows=fixture();rows.push({t:rows.at(-1).t+MIN,o:104,h:104.1,l:103.9,c:104,v:1});e=run(rows);assert.equal(e.tradeCount,0);assert.equal(e.counts.skipped,1);
// Positive funding pays shorts. An entry exactly on the funding minute does not receive it.
rows=fixture();const entryTime=rows.at(-1).t+MIN;extend(rows,62,108.6);
e=run(rows,settings,[{t:entryTime,rate:.1,price:200},{t:entryTime+MIN,rate:.001,price:200}]);
assert.equal(e.logs.length,1);assert.equal(e.logs[0].reason,'持仓时间到期');assert.equal(e.logs[0].closedAt-e.logs[0].openedAt,HOUR);
assert.ok(Math.abs(e.fundingTotal-e.logs[0].qty*200*.001)<1e-8);reconcile(e,rows.at(-1).c);
// Mirror data tests the long branch independently, including target execution and signed funding.
rows=fixture();extend(rows,1,108.6);extend(rows,1,103);
const mirrored=rows.map(b=>({...b,o:200-b.o,h:200-b.l,l:200-b.h,c:200-b.c}));
e=run(mirrored,settings,[{t:entryTime+MIN,rate:.001,price:100}]);assert.equal(e.logs[0].side,'long');assert.equal(e.logs[0].reason,'目标退出');assert.ok(e.logs[0].pnl>0);assert.ok(e.fundingTotal<0);reconcile(e,mirrored.at(-1).c);
rows=background();extend(rows,125,112);e=run(rows);assert.equal(e.tradeCount,0);assert.equal(e.counts.expired,1,'Continuing strength expires instead of forcing a trade');
// Fee/funding/PnL math and strict parser boundaries.
assert.throws(()=>new ExhaustionEngine({...settings,takerFee:NaN}));assert.throws(()=>new ExhaustionEngine(settings,[{t:T+1,rate:.001}]));
const invalid=background().slice(0,2);invalid[1].t+=MIN;assert.throws(()=>run(invalid));
const tiny=run([...fixture(),{t:entryTime,o:108.6,h:108.61,l:108.59,c:108.6,v:1}],{...settings,riskUsdt:1e-8});assert.equal(tiny.tradeCount,0);
// Prefix causality: streaming code has no access to the rest of an imported file.
rows=fixture();extend(rows,120,105);const n=4456, first=run(rows.slice(0,n)), full=new ExhaustionEngine(settings);rows.slice(0,n).forEach(b=>full.step(b));assert.deepEqual(norm(first.view(rows[n-1].c)),norm(full.view(rows[n-1].c)));
// Exercise actual Worker protocol and full-file vs truncated-file prefix.
const workerSource=fs.readFileSync(path.join(__dirname,'../src/tradfi-replay/replay.worker.ts'),'utf8');
function workerRun(data,until){const messages=[],scope={postMessage:m=>messages.push(norm(m)),setInterval,clearInterval};const ctx={exports:{},require:name=>{assert.equal(name,'./exhaustionEngine');return context.exports;},self:scope,clearInterval};vm.createContext(ctx);vm.runInContext(ts.transpileModule(workerSource,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText+'\nself.advanceTest=advance;',ctx);scope.onmessage({data:{type:'init-start',candleCount:data.length,settings,funding:[]}});const flat=new Float64Array(data.flatMap(b=>[b.t,b.o,b.h,b.l,b.c,b.v]));scope.onmessage({data:{type:'init-chunk',start:0,count:data.length,buffer:flat.buffer}});scope.onmessage({data:{type:'init-complete'}});assert.ok(messages.some(m=>m.type==='ready'));scope.advanceTest(until);assert.ok(!messages.some(m=>m.type==='replay-error'));return messages.filter(m=>m.type==='tick').at(-1).payload;}
const w1=workerRun(rows,n),w2=workerRun(rows.slice(0,n),n);for(const s of [w1,w2]){delete s.total;delete s.progress;delete s.paused;}assert.deepEqual(w1,w2,'Imported future rows cannot influence Worker prefix');
console.log('Event replay passed: idle/trend/impulse gates, sequential exhaustion, next-open entry, no adds/rebuild, risk/RR/gap checks, short and long exits, time limit, funding/fees/PnL, event expiry, immutable ATR, Worker prefix causality.');
