// Causal event-driven replay. No network, AI decisions, averaging down or re-entry.
export type Candle = { t: number; o: number; h: number; l: number; c: number; v: number };
export type Funding = { t: number; rate: number; price?: number };
export type Side = 'long' | 'short';
export const EVENT_RULES = Object.freeze({ backgroundHours: 72, atrHours: 14, impulseAtr: 2,
  impulsePct: .5, backgroundAtr: 1, efficiency: .3, pullbackAtr: .5, bounceAtr: .25,
  stopBufferAtr: .25, observeHours: 2, episodeHours: 6, minRR: 1.2, maxEquityRiskPct: 1 });
export type Settings = { symbol: string; marginUsdt: number; leverage: number; walletBalance: number;
  takerFee: number; slippage: number; tickSize: number; qtyStep: number; riskUsdt: number; maxHoldHours: number };
type Event = { id: string; direction: 1 | -1; side: Side; t: number; expires: number; atr: number;
  reference: number; extreme: number; stage: 'IMPULSE' | 'PULLBACK' | 'BOUNCE'; low: number;
  bounceHigh: number; backgroundPct: number; impulsePct: number; efficiency: number; status: string; reason?: string;
  entryCheck?: { time: number; entry: number; stop: number; target: number; riskPerUnit: number; rewardPerUnit: number; netRR: number } };
type Position = { side: Side; qty: number; avg: number; margin: number; fee: number; funding: number;
  openedAt: number; stop: number; target: number; plannedRisk: number; event: Event; fills: any[]; adds: number };
const MIN = 60000, HOUR = 60 * MIN;
class Aggregator {
  private bar: Candle | null = null;
  private count = 0;
  private minutes: number;
  constructor(minutes: number) { this.minutes = minutes; }
  push(b: Candle): Candle | null {
    const t = Math.floor(b.t / (MIN * this.minutes)) * MIN * this.minutes;
    if (!this.bar || this.bar.t !== t) { this.bar = { ...b, t }; this.count = 1; }
    else { this.bar.h = Math.max(this.bar.h, b.h); this.bar.l = Math.min(this.bar.l, b.l); this.bar.c = b.c; this.bar.v += b.v; this.count++; }
    if (b.t + MIN !== t + this.minutes * MIN) return null;
    const result = this.count === this.minutes ? { ...this.bar } : null;
    this.bar = null; this.count = 0; return result;
  }
}
export function validateSettings(s: Settings) {
  if (!s.symbol || ![s.marginUsdt,s.leverage,s.walletBalance,s.takerFee,s.slippage,s.tickSize,s.qtyStep,s.riskUsdt,s.maxHoldHours].every(Number.isFinite)
    || s.marginUsdt <= 0 || s.walletBalance <= 0 || s.riskUsdt <= 0 || s.tickSize <= 0 || s.qtyStep <= 0
    || s.leverage < 1 || s.leverage > 10 || s.takerFee < 0 || s.takerFee > .05 || s.slippage < 0 || s.slippage > .05
    || s.maxHoldHours < 1 || s.maxHoldHours > 48) throw new Error('策略参数无效：杠杆 1–10×、最长持仓 1–48 小时，资金/步进为正，费率与滑点 0–5%');
}
export class ExhaustionEngine {
  readonly settings: Settings;
  private hour = new Aggregator(60);
  private five = new Aggregator(5);
  private hours: Candle[] = [];
  private lastTime: number | null = null;
  private locks = { long: 0, short: 0 };
  private fundingIndex = 0;
  private pending: { event: Event; signalAt: number; stop: number; target: number } | null = null;
  private event: Event | null = null;
  position: Position | null = null;
  logs: any[] = [];
  events: Event[] = [];
  state = '空仓等待 · 预热 74 根完整小时线';
  counts = { detected: 0, confirmed: 0, entered: 0, skipped: 0, expired: 0 };
  realized = 0; fees = 0; fundingTotal = 0; realizedFunding = 0; tradeCount = 0;
  realizedBySide = { long: 0, short: 0 };
  distribution = { large: 0, small: 0 };
  equity: number; equityPeak: number; maxDrawdown = 0; maxDrawdownPct = 0; marginPeak = 0;
  lossPeak = { long: 0, short: 0, total: 0 };
  lossContext: Record<Side, any> = { long: null, short: null };
  totalLossPeakTime = 0;
  losingMinutes = { long: 0, short: 0 }; losingStreak = { long: 0, short: 0 }; maxLosingStreak = { long: 0, short: 0 };
  private funding: Funding[];
  constructor(settings: Settings, funding: Funding[] = []) {
    this.funding = funding.map(f => ({ ...f }));
    validateSettings(settings); this.settings = { ...settings }; this.equity = this.equityPeak = settings.walletBalance;
    funding.forEach((f,i) => { if (!Number.isFinite(f.t) || f.t % MIN || !Number.isFinite(f.rate)
      || (f.price !== undefined && !(Number.isFinite(f.price) && f.price > 0)) || (i && f.t <= funding[i-1].t)) throw new Error('资金费须按时间严格递增、对齐分钟且参考价有效'); });
  }
  pnl(price: number) { const p = this.position; return p ? (p.side === 'long' ? price-p.avg : p.avg-price)*p.qty + p.funding-p.fee : 0; }
  private round(price: number, up: boolean) { return (up ? Math.ceil(price / this.settings.tickSize - 1e-9) : Math.floor(price / this.settings.tickSize + 1e-9)) * this.settings.tickSize; }
  private execution(price: number, buy: boolean) { return this.round(price*(1+(buy ? 1 : -1)*this.settings.slippage), buy); }
  private finishEvent(status: string, reason: string) {
    if (this.event) { this.event.status = status; this.event.reason = reason; }
    this.state = reason; this.event = null; this.pending = null;
  }
  private close(price: number, b: Candle, reason: string) {
    const p = this.position!;
    const exit = this.execution(price, p.side === 'short'), fee = exit*p.qty*this.settings.takerFee;
    const net = this.pnl(exit)-fee;
    this.fees += fee; this.tradeCount++; this.realized += net; this.realizedBySide[p.side] += net; this.realizedFunding += p.funding;
    if (net >= 10) this.distribution.large++; else if (net >= 0) this.distribution.small++;
    this.logs.push({ id: `${p.event.id}-${b.t}`, type: 'position-close', time: b.t, text: reason, reason,
      side: p.side, symbol: this.settings.symbol, openedAt: p.openedAt, closedAt: b.t, openPrice: p.avg,
      closePrice: exit, qty: p.qty, pnl: net, fee: p.fee+fee, funding: p.funding,
      plannedRisk: p.plannedRisk, stop: p.stop, target: p.target, event: { ...p.event }, fills: p.fills });
    this.position = null; this.finishEvent('CLOSED', `${reason} · 空仓等待新事件`);
  }
  private enter(b: Candle) {
    const q = this.pending!; this.pending = null;
    const s = this.settings, e = q.event, buy = e.side === 'long';
    const entry = this.execution(b.o, buy), stopExit = this.execution(q.stop, !buy), targetExit = this.execution(q.target, !buy);
    const sign = buy ? 1 : -1, risk = sign*(entry-stopExit)+(entry+stopExit)*s.takerFee;
    const reward = sign*(targetExit-entry)-(entry+targetExit)*s.takerFee;
    const equity = s.walletBalance+this.realized;
    const budget = Math.min(s.riskUsdt, equity*EVENT_RULES.maxEquityRiskPct/100);
    e.entryCheck = { time: b.t, entry, stop:q.stop, target:q.target, riskPerUnit:risk, rewardPerUnit:reward, netRR:risk>0?reward/risk:0 };
    // Recheck at actual next open: gaps cannot turn a stale signal into an unlimited-risk fill.
    if (b.t !== q.signalAt || b.t >= e.expires || equity <= 0 || entry <= 0 || stopExit <= 0 || targetExit <= 0
      || sign*(entry-q.stop) <= 0 || sign*(q.target-entry) <= 0 || risk <= 0 || reward/risk < EVENT_RULES.minRR
      || Math.abs(entry-q.stop)/entry >= .8/s.leverage) {
      const reason = b.t !== q.signalAt || b.t >= e.expires ? '入场信号超时'
        : equity <= 0 ? '账户权益不足'
        : entry <= 0 || stopExit <= 0 || targetExit <= 0 || sign*(entry-q.stop) <= 0 || sign*(q.target-entry) <= 0 ? '跳空已越过止损或目标'
        : risk <= 0 ? '计划风险距离无效'
        : reward/risk < EVENT_RULES.minRR ? `扣费后收益风险比 ${(reward/risk).toFixed(2)} < ${EVENT_RULES.minRR}`
        : '止损距离超过当前杠杆的保守限制';
      this.counts.skipped++; this.finishEvent('SKIPPED', `${reason}，放弃事件`); return;
    }
    const raw = Math.min(budget/risk, s.marginUsdt*s.leverage/entry, equity/(entry/s.leverage+entry*s.takerFee));
    const qty = Math.floor(raw/s.qtyStep)*s.qtyStep;
    if (!(qty > 0) || qty*risk > budget+1e-8) { this.counts.skipped++; this.finishEvent('SKIPPED', '风险预算内数量不足一个步进，放弃事件'); return; }
    const fee = qty*entry*s.takerFee, margin = qty*entry/s.leverage;
    this.position = { side: e.side, qty, avg: entry, margin, fee, funding: 0, openedAt: b.t,
      stop: q.stop, target: q.target, plannedRisk: qty*risk, event: { ...e }, adds: 0,
      fills: [{ time: b.t, price: entry, qty, margin, purpose: 'open', tierStart: 0, tierEnd: 0, label: '异常后衰竭确认 · 单次入场' }] };
    this.fees += fee; this.tradeCount++; this.counts.entered++; this.marginPeak = Math.max(this.marginPeak, margin);
    e.status = 'ENTERED'; this.state = `${buy ? '多' : '空'}仓持有 · 固定止损/目标/时间退出 · 禁止补仓`;
  }
  private detect(h: Candle) {
    if (this.hours.length < 74) return;
    if (this.position || this.pending || this.event) return;
    this.state = '空仓等待 · 尚无趋势加速与衰竭机会';
    if (this.settings.walletBalance+this.realized <= 0) { this.state = '权益耗尽 · 停止开仓'; return; }
    const a = this.hours, prev = a[72];
    let atr = 0; for (let i=59;i<=72;i++) atr += Math.max(a[i].h-a[i].l,Math.abs(a[i].h-a[i-1].c),Math.abs(a[i].l-a[i-1].c)); atr /= 14;
    const background = prev.c-a[0].c, move = h.c-prev.c;
    const travel = a.slice(1,73).reduce((sum,b,i)=>sum+Math.abs(b.c-a[i].c),0);
    const efficiency = travel ? Math.abs(background)/travel : 0;
    if (!(atr > 0) || background*move <= 0 || Math.abs(background) < EVENT_RULES.backgroundAtr*atr
      || efficiency < EVENT_RULES.efficiency || Math.abs(move) < EVENT_RULES.impulseAtr*atr
      || Math.abs(move)/prev.c*100 < EVENT_RULES.impulsePct) return;
    const direction = move > 0 ? 1 : -1, side = direction === 1 ? 'short' : 'long', t = h.t+HOUR;
    if (t < this.locks[side]) { this.state = '同向事件冷却 · 不反复抄顶抄底'; return; }
    this.locks[side] = t+EVENT_RULES.episodeHours*HOUR;
    this.event = { id: `${this.settings.symbol}-${t}-${side}`, direction, side, t,
      expires: t+EVENT_RULES.observeHours*HOUR, atr, reference: prev.c,
      extreme: direction === 1 ? h.h : -h.l, stage: 'IMPULSE', low: 0, bounceHigh: 0,
      backgroundPct: background/a[0].c*100, impulsePct: move/prev.c*100, efficiency, status: 'OBSERVING' };
    this.events.push(this.event); this.counts.detected++; this.state = '异常加速 · 等待有效回撤，不立即逆势开仓';
  }
  private confirm(b: Candle) {
    const e = this.event;
    if (!e || this.position || this.pending || b.t < e.t) return;
    const hi = e.direction === 1 ? b.h : -b.l, lo = e.direction === 1 ? b.l : -b.h, close = b.c*e.direction;
    // All state changes use a completed bar. One transition per bar prevents invented intrabar ordering.
    if (hi >= e.extreme) { e.extreme = hi; e.stage = 'IMPULSE'; e.low = 0; e.bounceHigh = 0; this.state = '趋势继续延伸 · 重置结构，保留原事件与 ATR'; return; }
    if (e.stage === 'IMPULSE') {
      if (e.extreme-close >= EVENT_RULES.pullbackAtr*e.atr) { e.low = lo; e.stage = 'PULLBACK'; this.state = '有效回撤 · 等待反弹形成'; }
      return;
    }
    if (e.stage === 'PULLBACK') {
      if (lo < e.low) { e.low = lo; return; }
      if (close-e.low >= EVENT_RULES.bounceAtr*e.atr) { e.bounceHigh = hi; e.stage = 'BOUNCE'; this.state = '反弹形成 · 等待跌破回撤低点（下跌事件镜像）'; }
      return;
    }
    e.bounceHigh = Math.max(e.bounceHigh, hi);
    if (close < e.low) {
      const stopRaw = e.direction*(e.extreme+EVENT_RULES.stopBufferAtr*e.atr);
      const stop = this.round(stopRaw, e.side === 'short'), target = this.round(e.reference, e.side === 'long');
      this.pending = { event: e, signalAt: b.t+5*MIN, stop, target }; e.status = 'CONFIRMED';
      this.counts.confirmed++; this.state = '衰竭结构确认 · 下一分钟开盘重新检查成本与风险';
    }
  }
  step(b: Candle) {
    if (![b.t,b.o,b.h,b.l,b.c,b.v].every(Number.isFinite) || b.t%MIN || b.l<=0 || b.h<Math.max(b.o,b.c,b.l)
      || b.l>Math.min(b.o,b.c) || b.v<0 || (this.lastTime!==null && b.t-this.lastTime!==MIN)) throw new Error('分钟线必须连续且 OHLC 有效');
    this.lastTime = b.t;
    // At timestamp funding belongs to positions held before any same-minute entry/exit.
    while (this.fundingIndex<this.funding.length && this.funding[this.fundingIndex].t<=b.t) {
      const f = this.funding[this.fundingIndex++];
      if (this.position && f.t === b.t) { const cash = (this.position.side==='long'?-1:1)*this.position.qty*(f.price ?? b.o)*f.rate; this.position.funding+=cash; this.fundingTotal+=cash; }
    }
    if (this.pending) this.enter(b);
    if (this.position) {
      const p = this.position, long = p.side==='long';
      const stopGap = long ? b.o<=p.stop : b.o>=p.stop, targetGap = long ? b.o>=p.target : b.o<=p.target;
      if (stopGap) this.close(b.o,b,'跳空止损');
      else if (targetGap) this.close(b.o,b,'目标退出');
      else if (b.t-p.openedAt>=this.settings.maxHoldHours*HOUR) this.close(b.o,b,'持仓时间到期');
      else if (long ? b.l<=p.stop : b.h>=p.stop) this.close(p.stop,b,'价格止损');
      else if (long ? b.h>=p.target : b.l<=p.target) this.close(p.target,b,'目标退出');
    }
    if (this.event && !this.position && !this.pending && b.t+MIN>=this.event.expires) { this.counts.expired++; this.finishEvent('EXPIRED','观察超时 · 放弃事件，等待新机会'); }
    const h = this.hour.push(b), five = this.five.push(b);
    if (h) { this.hours.push(h); if (this.hours.length>74) this.hours.shift(); this.detect(h); }
    if (five) this.confirm(five);
    this.mark(b);
  }
  private mark(b: Candle) {
    const pnl = this.pnl(b.c), p = this.position;
    if (p) {
      const loss = Math.max(0,-pnl);
      if (loss>this.lossPeak[p.side]) { this.lossPeak[p.side]=loss; this.lossContext[p.side]={time:b.t,price:b.c,entryPrice:p.avg,margin:p.margin,additions:0,phase:'event',deepStage:0,deepBudget:0,fills:p.fills}; }
      if (loss>this.lossPeak.total) { this.lossPeak.total=loss; this.totalLossPeakTime=b.t; }
    }
    for (const side of ['long','short'] as Side[]) {
      if (p?.side===side && pnl<0) { this.losingMinutes[side]++; this.losingStreak[side]++; this.maxLosingStreak[side]=Math.max(this.maxLosingStreak[side],this.losingStreak[side]); }
      else this.losingStreak[side]=0;
    }
    this.equity=this.settings.walletBalance+this.realized+pnl; this.equityPeak=Math.max(this.equityPeak,this.equity);
    this.maxDrawdown=Math.max(this.maxDrawdown,this.equityPeak-this.equity);
    this.maxDrawdownPct=Math.max(this.maxDrawdownPct,(this.equityPeak-this.equity)/this.equityPeak*100);
  }
  view(price: number) {
    const p = this.position;
    return { state:this.state,symbol:this.settings.symbol,positions:{long:null,short:null,...(p?{[p.side]:{...p,pnl:this.pnl(price),notional:p.qty*price}}:{})},
      orders:{long:null,short:null,...(this.pending?{[this.pending.event.side]:{purpose:'open',price:null,label:'下一分钟开盘入场（待风险检查）'}}:{})},
      realized:this.realized,realizedBySide:{...this.realizedBySide},realizedFunding:this.realizedFunding,fees:this.fees,funding:this.fundingTotal,
      unrealized:this.pnl(price),net:this.realized+this.pnl(price),tradeCount:this.tradeCount,positionDistribution:{...this.distribution},
      equity:this.equity,maxDrawdown:this.maxDrawdown,maxDrawdownPct:this.maxDrawdownPct,marginPeak:this.marginPeak,
      maxLossPeak:{...this.lossPeak},lossPeakContext:this.lossContext,totalLossPeakTime:this.totalLossPeakTime,
      losingMinutes:{...this.losingMinutes},maxLosingStreak:{...this.maxLosingStreak},market:null,
      eventStats:{...this.counts},activeEvent:this.event?{...this.event}:null,recentEvents:this.events.slice(-20).map(e=>({...e})),
      special:{placed:0,filled:0,canceled:0,realized:0,margin:{long:0,short:0}} };
  }
}
