export const goldStrategy = {
  id: 'gold-range' as const, name: '区间回归策略', subtitle: '趋势背景 · 过冲衰竭 · 单次入场', version: 'event-reversion-v2.0', minimum: 4500,
  description: '默认空仓，异常加速后等待衰竭确认；禁止补仓与同向重建，固定止损和时间退出。',
};
export function createReplayWorker(): Worker {
  return new Worker(new URL('./replay.worker.ts', import.meta.url), { type: 'module' });
}

export function isGoldStrategyReport(report: { strategyId?: string; strategyName: string }): boolean {
  return report.strategyId ? report.strategyId === goldStrategy.id : ['黄金震荡＋补仓', goldStrategy.name].includes(report.strategyName);
}
